import {auth,db,QR_CODE_URL,onAuthStateChanged,signOut,doc,getDoc,collection,query,where,getDocs,orderBy,addDoc,serverTimestamp,runTransaction} from "./firebase.js";
const $=x=>document.getElementById(x),PRICE=599;let user;
$("qr").src=QR_CODE_URL;
$("qty").oninput=()=>{$("total").textContent=Math.max(1,Math.min(20,+$("qty").value||1))*PRICE};
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
const st=s=>`<span class="status ${s}">${esc(s)}</span>`;
async function load(){
 let u=await getDoc(doc(db,"users",user.uid));$("credits").textContent=u.exists()?u.data().credits||0:0;
 let fs=await getDocs(query(collection(db,"files"),where("active","==",true)));
 $("files").innerHTML=fs.empty?"<p>No files available.</p>":fs.docs.map(d=>{let x=d.data();return `<div class="file"><div><b>${esc(x.title)}</b><p>${esc(x.description)}</p></div><button class="dl" data-id="${d.id}" data-url="${esc(x.url)}">Download (1 credit)</button></div>`}).join("");
 document.querySelectorAll(".dl").forEach(b=>b.onclick=()=>download(b.dataset.id,b.dataset.url));
 let ps=await getDocs(query(collection(db,"payments"),where("uid","==",user.uid),orderBy("createdAt","desc")));
 $("history").innerHTML=ps.empty?"<p>No payment requests.</p>":ps.docs.map(d=>{let x=d.data();return `<div class="history"><span>₹${x.amount}</span><span>${esc(x.utr)}</span>${st(x.status)}</div>`}).join("");
}
async function download(fileId,url){
 try{await runTransaction(db,async tx=>{let r=doc(db,"users",user.uid),s=await tx.get(r);let c=s.data()?.credits||0;if(c<1)throw Error("Not enough credits.");tx.update(r,{credits:c-1});tx.set(doc(collection(db,"downloads")),{uid:user.uid,fileId,createdAt:serverTimestamp()})});location.href=url;await load()}catch(e){alert(e.message)}
}
function compress(file){return new Promise((resolve,reject)=>{let r=new FileReader();r.onload=()=>{let i=new Image();i.onload=()=>{let scale=Math.min(1,1000/i.width),c=document.createElement("canvas");c.width=i.width*scale;c.height=i.height*scale;c.getContext("2d").drawImage(i,0,0,c.width,c.height);let d=c.toDataURL("image/jpeg",.6);if(d.length>700000)reject(Error("Screenshot too large. Choose a smaller image."));else resolve(d)};i.onerror=reject;i.src=r.result};r.onerror=reject;r.readAsDataURL(file)})}
$("submit").onclick=async()=>{let name=$("name").value.trim(),email=$("email").value.trim(),utr=$("utr").value.trim(),qty=Math.max(1,Math.min(20,+$("qty").value||1)),file=$("shot").files[0];if(!name||!email||!utr||!file)return $("paymsg").textContent="All fields are required.";try{$("submit").disabled=true;$("paymsg").textContent="Submitting…";let screenshot=await compress(file);await addDoc(collection(db,"payments"),{uid:user.uid,name,email,utr,credits:qty,amount:qty*PRICE,screenshot,status:"pending",createdAt:serverTimestamp()});$("paymsg").textContent="Submitted. Waiting for admin approval.";await load()}catch(e){$("paymsg").textContent=e.message}finally{$("submit").disabled=false}};
$("logout").onclick=()=>signOut(auth);
onAuthStateChanged(auth,async u=>{if(!u)return location.href="login.html";user=u;$("loading").hidden=true;$("app").hidden=false;$("email").value=u.email||"";try{await load()}catch(e){$("files").textContent=e.message}});
