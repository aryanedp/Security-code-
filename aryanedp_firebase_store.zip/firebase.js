import { initializeApp } from "https://www.gstatic.com/firebasejs/12.17.1/firebase-app.js";
import { getAuth,onAuthStateChanged,signInWithEmailAndPassword,createUserWithEmailAndPassword,signOut } from "https://www.gstatic.com/firebasejs/12.17.1/firebase-auth.js";
import { getFirestore,doc,getDoc,setDoc,addDoc,collection,query,where,getDocs,orderBy,updateDoc,runTransaction,serverTimestamp } from "https://www.gstatic.com/firebasejs/12.17.1/firebase-firestore.js";

const firebaseConfig={
 apiKey:"AIzaSyBHhIk2__hrMKZVB_0O5DP5whoYDDgsd-M",
 authDomain:"aryanedp-27244.firebaseapp.com",
 projectId:"aryanedp-27244",
 storageBucket:"aryanedp-27244.firebasestorage.app",
 messagingSenderId:"112075941241",
 appId:"1:112075941241:web:657a9f8d34fbbde43a3ba8",
 measurementId:"G-KTYJCJDVVG"
};
export const app=initializeApp(firebaseConfig);
export const auth=getAuth(app);
export const db=getFirestore(app);
export const ADMIN_UID="Z6Fn1RCK3nW9khXXCmYNSDt9U4I3";
export const QR_CODE_URL="https://cdn.phototourl.com/free/2026-08-11-5c2901fb-bbe5-4a5d-adc8-f34a1a4a43bc.png";
export {onAuthStateChanged,signInWithEmailAndPassword,createUserWithEmailAndPassword,signOut,doc,getDoc,setDoc,addDoc,collection,query,where,getDocs,orderBy,updateDoc,runTransaction,serverTimestamp};
