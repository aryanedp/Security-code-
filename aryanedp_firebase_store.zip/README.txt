SETUP
1. Firebase Console -> Authentication -> Sign-in method -> Email/Password ON.
2. Firebase Console -> Firestore Database -> Create database.
3. Firestore -> Rules -> paste firestore.rules -> Publish.
4. Authentication -> Users -> create your admin account. Its UID must be:
   Z6Fn1RCK3nW9khXXCmYNSDt9U4I3
5. Host these files on HTTPS/Firebase Hosting.
6. Open login.html to create/login as a user.
7. Open admin.html with the admin account.

IMPORTANT
This version intentionally does not require Firebase Storage. Payment screenshots are compressed in the browser and stored in Firestore. A screenshot that remains too large is rejected because Firestore documents have a size limit.
Files are represented by download URLs added by the admin.
Payment approval is manual: admin verifies UTR/screenshot, then clicks Approve.
This is a generic digital-download store and does not contain unauthorized-access, credential theft, malware, or bypass tooling.
